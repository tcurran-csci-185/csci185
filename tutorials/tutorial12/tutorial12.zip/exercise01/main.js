function makeRed() {
    // your code here...
    console.log('Change the box\'s background color to red');
}

function makeBlue() {
    // your code here...
    console.log('Change the box\'s background color to blue');
}

function makePink() {
    // your code here...
    console.log('Change the box\'s background color to pink');
}

function makeOrange() {
    // your code here...
    console.log('Change the box\'s background color to orange');
}

